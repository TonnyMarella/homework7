print("hello world")
a = input("Если хотите завершить программу, нажмите Enter")