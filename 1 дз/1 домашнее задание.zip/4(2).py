print("Hello user!")
Name = input("What your name? ")

print("Your name - ", Name)