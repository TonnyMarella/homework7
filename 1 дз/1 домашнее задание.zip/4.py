print("Hello user!")
print("Your name - Artem")