a = 0

for i in range(20):
    a += 1
    print('*', end='')
    print()
    for j in range(a):
        print('*', end='')
print('*')