a = int(input("Введите число a\n"))
b = int(input("Введите число b(больше а)\n"))

summ = 0
count = 0

while a <= b:
    summ += a
    count += 1
    a += 1

print("Сумма =", summ)
summ /= i
print("Среднее арифметическое = " summ)