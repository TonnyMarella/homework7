from django.apps import AppConfig


class Lesson2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lesson_2'
